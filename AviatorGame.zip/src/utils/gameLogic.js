export function generateCrashPoint() {
  return Math.random() * (5 - 1) + 1; // Random crash point between 1x and 5x
}
