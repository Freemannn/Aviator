import React, { useState, useEffect } from "react";
import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import { generateCrashPoint } from "../utils/gameLogic";

const AviatorScreen = () => {
  const [multiplier, setMultiplier] = useState(1);
  const [crashPoint, setCrashPoint] = useState(generateCrashPoint());
  const [isFlying, setIsFlying] = useState(false);

  useEffect(() => {
    let timer;
    if (isFlying) {
      timer = setInterval(() => {
        setMultiplier((prev) => prev + 0.1);
      }, 100);
    } else {
      clearInterval(timer);
    }
    return () => clearInterval(timer);
  }, [isFlying]);

  const handleStart = () => {
    setIsFlying(true);
    setCrashPoint(generateCrashPoint());
    setMultiplier(1);
  };

  const handleCashOut = () => {
    setIsFlying(false);
    if (multiplier >= crashPoint) {
      alert("Crash! You lose!");
    } else {
      alert(`You cashed out at ${multiplier.toFixed(2)}x!`);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Aviator Game</Text>
      <Text style={styles.multiplier}>Multiplier: {multiplier.toFixed(2)}x</Text>
      <Text style={styles.crashPoint}>Crash Point: {crashPoint.toFixed(2)}x</Text>
      <View style={styles.buttons}>
        <TouchableOpacity onPress={handleStart} style={styles.startButton}>
          <Text style={styles.buttonText}>Start</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={handleCashOut} style={styles.cashOutButton}>
          <Text style={styles.buttonText}>Cash Out</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: "center", alignItems: "center" },
  title: { fontSize: 32, fontWeight: "bold", marginBottom: 20 },
  multiplier: { fontSize: 24, marginVertical: 10 },
  crashPoint: { fontSize: 18, marginBottom: 30 },
  buttons: { flexDirection: "row", justifyContent: "space-around", width: "80%" },
  startButton: { backgroundColor: "green", padding: 15, borderRadius: 5 },
  cashOutButton: { backgroundColor: "red", padding: 15, borderRadius: 5 },
  buttonText: { color: "white", fontSize: 18 },
});

export default AviatorScreen;
